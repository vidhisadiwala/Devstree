import axios from "axios";

import {productApi,userApi} from "./api";



const prodApi = async () => {

  let newData = await axios.get(`${productApi}`)
  if (newData) {
    console.log("aaa",newData);
    return newData.data.products
  }
  else {
    return false
  }
}



const uApi = async () => {

  let newUserData = await axios.get(`${userApi}`)
  if (newUserData) {
    console.log("user",newUserData);
    return newUserData.data.users
  }
  else {
    return false
  }
}




export {uApi,prodApi}