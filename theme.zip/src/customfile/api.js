export const userApi='https://dummyjson.com/users';
export const productApi = 'https://dummyjson.com/products';




